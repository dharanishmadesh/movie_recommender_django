from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('recommend/title/', views.recommend_by_title, name='recommend_title'),
    path('recommend/user/', views.recommend_by_user, name='recommend_user'),
]

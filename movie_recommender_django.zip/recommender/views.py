from django.shortcuts import render
from django.conf import settings
from .utils import Recommender

# instantiate a single recommender (loads data lazily)
rec = Recommender(data_dir='data')

def home(request):
    return render(request, 'home.html', {})

def recommend_by_title(request):
    query = request.GET.get('title', '').strip()
    results = []
    message = ''
    if query:
        try:
            results = rec.recommend_content_based(query, top_k=10)
            if isinstance(results, str):
                message = results
                results = []
        except Exception as e:
            message = str(e)
    return render(request, 'recommend_title.html', {'query': query, 'results': results, 'message': message})

def recommend_by_user(request):
    uid = request.GET.get('user_id', '').strip()
    results = []
    message = ''
    if uid:
        try:
            uid_int = int(uid)
            results = rec.recommend_collaborative(uid_int, n=10)
            if isinstance(results, str):
                message = results
                results = []
        except ValueError:
            message = 'Invalid user id'
        except Exception as e:
            message = str(e)
    return render(request, 'recommend_user.html', {'user_id': uid, 'results': results, 'message': message})

import ast
import os
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class Recommender:
    def __init__(self, data_dir='data'):
        self.base = Path(data_dir)
        self.movies = pd.DataFrame()
        self.ratings = pd.DataFrame()
        self.tfidf = None
        self.tfidf_matrix = None
        self.title_to_indices = {}
        self.user_movie_matrix = pd.DataFrame()
        self.user_similarity_df = pd.DataFrame()
        self.load_data()

    def load_data(self):
        movies_path = self.base / 'movies_metadata.csv'
        ratings_path = self.base / 'ratings.csv'
        if not movies_path.exists() or not ratings_path.exists():
            # lazy: don't raise here; views will show an informative message
            return

        movies = pd.read_csv(movies_path, low_memory=False)
        ratings = pd.read_csv(ratings_path)

        # minimal cleaning (adapt from original)
        if 'id' in movies.columns:
            movies = movies.rename(columns={'id': 'movieId'})
        movies['movieId'] = pd.to_numeric(movies['movieId'], errors='coerce')
        movies = movies.dropna(subset=['movieId'])
        movies['movieId'] = movies['movieId'].astype(int)
        movies['title'] = movies.get('title', '').fillna('').astype(str)
        movies['overview'] = movies.get('overview', '').fillna('').astype(str)

        # genres parsing simplified
        def extract_genres(x):
            try:
                if pd.isna(x):
                    return []
                if isinstance(x, str):
                    parsed = ast.literal_eval(x)
                    if isinstance(parsed, list):
                        return [g.get('name') if isinstance(g, dict) and 'name' in g else str(g) for g in parsed]
            except Exception:
                return []
            return []

        movies['genres_list'] = movies.get('genres', '').apply(extract_genres)

        self.movies = movies
        self.ratings = ratings

        # build tfidf if we have overviews
        if self.movies['overview'].str.len().sum() > 0:
            self.tfidf = TfidfVectorizer(stop_words='english', max_df=0.85, min_df=2)
            try:
                self.tfidf_matrix = self.tfidf.fit_transform(self.movies['overview'])
                self.title_to_indices = self.movies.reset_index().groupby('title')['index'].apply(list).to_dict()
            except Exception:
                self.tfidf_matrix = None

        # collaborative
        merged = pd.merge(self.ratings, self.movies[['movieId', 'title']], on='movieId', how='inner')
        rating_col = 'rating' if 'rating' in merged.columns else None
        if rating_col:
            sample = merged[merged['userId'] <= 1000]
            if not sample.empty:
                self.user_movie_matrix = sample.pivot_table(index='userId', columns='title', values=rating_col).fillna(0)
                try:
                    sim = cosine_similarity(self.user_movie_matrix)
                    self.user_similarity_df = pd.DataFrame(sim, index=self.user_movie_matrix.index, columns=self.user_movie_matrix.index)
                except Exception:
                    self.user_similarity_df = pd.DataFrame()

    def _cosine_similarity_in_chunks(self, vec, matrix, chunk_size=10000):
        m = matrix.shape[0]
        sims = np.zeros(m, dtype=np.float64)
        for start in range(0, m, chunk_size):
            end = min(start + chunk_size, m)
            chunk = matrix[start:end]
            sims[start:end] = cosine_similarity(vec, chunk).flatten()
        return sims

    def recommend_content_based(self, title, top_k=10):
        if self.tfidf_matrix is None:
            return "TF-IDF model not available. Ensure movies_metadata.csv with overviews is in the data folder."
        if title not in self.title_to_indices:
            return f"Movie '{title}' not found."
        idx = self.title_to_indices[title][0]
        try:
            sim_array = cosine_similarity(self.tfidf_matrix[idx], self.tfidf_matrix).flatten()
        except MemoryError:
            sim_array = self._cosine_similarity_in_chunks(self.tfidf_matrix[idx], self.tfidf_matrix)
        sim_array[idx] = -1
        top_indices = np.argsort(-sim_array)[:top_k]
        recs = self.movies.iloc[top_indices][['movieId', 'title', 'release_date']].to_dict(orient='records')
        return recs

    def recommend_collaborative(self, user_id, n=5):
        if self.user_similarity_df.empty or user_id not in self.user_similarity_df.index:
            return f"User ID {user_id} not found in sample or collaborative model unavailable."
        similar_users = self.user_similarity_df[user_id].sort_values(ascending=False).iloc[1:6]
        similar_idxs = similar_users.index
        weighted = self.user_movie_matrix.loc[similar_idxs].T.dot(similar_users.values) / (similar_users.values.sum() + 1e-9)
        user_rated = self.user_movie_matrix.loc[user_id]
        unread = weighted[user_rated == 0].sort_values(ascending=False)
        top_n = unread.head(n)
        return top_n.to_dict()

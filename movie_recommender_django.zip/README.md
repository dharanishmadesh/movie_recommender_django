# Movie Recommender (Django) — Starter Project

This is a minimal Django web UI wrapper around a movie recommender system (content-based + collaborative)
based on the Movies Metadata and Ratings CSV files.

## What's included
- Django project `movie_site`
- Django app `recommender`
- Basic UI: home page, search by title, user recommendations
- `recommender/utils.py` contains the data-loading and recommender functions (adapted from your script)
- `requirements.txt` lists required Python packages

## How to run (local)
1. Create a virtualenv: `python -m venv venv && source venv/bin/activate` (Windows: `venv\Scripts\activate`)
2. Install: `pip install -r requirements.txt`
3. Put `movies_metadata.csv` and `ratings.csv` in the folder `data/`
4. Run migrations & start server:
    ```
    python manage.py migrate
    python manage.py runserver
    ```
5. Open http://127.0.0.1:8000/

Notes:
- This is a starter scaffold. For large datasets, the first load will take time; consider precomputing TF-IDF and persisting it with `joblib`.
- Modify memory/performance settings as needed.


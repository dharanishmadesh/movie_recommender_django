Place movies_metadata.csv and ratings.csv in this folder before running the server.
